const menusTemplate = () => `<div class="card-detail" style="height:200px">
    </div>
    `;
export default menusTemplate;
